from setuptools import setup

setup(name='finalProj',
      version='0.1',
      description='Final Project',
      author='Justin Pham, Angelo Troncone',
      author_email='justin.pham@ucalgary.ca',
      packages=['dataStructures'],
      install_requires=[],
      )